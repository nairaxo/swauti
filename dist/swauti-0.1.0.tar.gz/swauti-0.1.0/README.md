# Swauti

Une bibliothèque Python pour transcrire et synthétiser de l'audio en Shikomori.

## Installation

```bash
pip install swauti